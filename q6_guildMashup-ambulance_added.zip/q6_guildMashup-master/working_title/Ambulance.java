import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * @author Matt Marler 
 * @version 3/13/18
 */
public class Ambulance extends Actor
{
    private GreenfootImage image1;
    private GreenfootImage image2;
    public void updateImage()
    {
        if (getImage() == image1)
        {
            setImage(image2);
        }
        else
        {
            setImage(image1);
        }
    }

    public Ambulance()
    {
        image1 = new GreenfootImage("ambulance.png");
        image2 = new GreenfootImage("ambulance2.png");
    }      

    //private void checkCollision()
    //{
    //if (isTouching(___.class))
    // {
    //  removeTouching(___.class);
    // Greenfoot.playSound("___.wav");
    // GuildWorld myworld = (GuildWorld)getWorld();
    //myworld.addScore(10);
    //}
    //}

    /** 
     * Move left and right.
     */
    public void checkKeyPress()
    {
        {
            if (Greenfoot.isKeyDown("a"))
            {
                setLocation(getX()-5, getY());
            }
        }
        {
            if (Greenfoot.isKeyDown("d"))
            {
                setLocation(getX()+5, getY());
            }
        }
    }

    /**
     * Move.
     */
    public void act()
    {
        checkKeyPress();
        //checkCollision();
        updateImage();
    }
}