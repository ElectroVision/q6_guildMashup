import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class background here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class BG extends ScrollObjects
{
    public static final int WIDTH = 800;
    public static final int HEIGHT = 400;
    /**
     * Act - do whatever the background wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
               
    }    
}
